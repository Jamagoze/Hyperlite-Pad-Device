package com.jama.highendhome;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityOptions;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
public class Hook implements IXposedHookLoadPackage {
private static final boolean HIGH_END = false;
private static final boolean MIUI_WIDGETS = true;
private static final boolean WIDGET_TO_MINUS = true;
private static final boolean WIDGET_RESIZABLE = true;
private static final boolean WIDGET_HIDE_TITLE = true;
private static final boolean WIDGET_ALL_ANIM = true;
private static final float TITLE_SIZE_DESKTOP = 10f;
private static final float TITLE_SIZE_DRAWER = 12f;
private static final boolean HIDE_REPORT_TEXT = true;
private static final boolean NEW_INSTALL_INDICATOR_OFF = true;
private static final boolean DOWNLOAD_ANIMATION = true;
private static final boolean DISABLE_RECENTS_ICON = true;
private static final boolean UNLOCK_HOTSEAT = true;
private static final boolean HOTSEAT_LAYOUT = false;
private static final int HOTSEAT_HEIGHT_DP = 150;
private static final int HOTSEAT_MARGIN_TOP_DP = 1;
private static final int HOTSEAT_MARGIN_BOTTOM_DP = 5;
private static final boolean RECENT_HIDE_CLEAN_UP = true;
private static final boolean RECENT_REMOVE_ICON = true;
private static final int RECENT_BLUR_LEVEL = 4;
private static final float TASK_HORIZONTAL_1 = 0.5f;
private static final float TASK_HORIZONTAL_2 = 0.5f;
private static final float TASK_VERTICAL = 0.5f;
private static final int TASK_CORNER_DP = 25;
private static final float ANIM_TITLE = 1.3f;
private static final float ANIM_RECENT = 1.6f;
private static final boolean DRAWER_ALL = true;
private static final boolean FOLDER_RECOMMEND_OFF = true;
private static final int FOLDER_VERTICAL_SPACING_DP = 60;
private static final boolean FOLDER_TITLE_CENTER = true;
private static final boolean TOAST_SLIDE_AGAIN = true;
private static final boolean OPT_LAUNCH_DELAY = true;
private static final boolean SEEK_POINTS_HIDE = true;
private static final boolean SHORTCUT_COUNT = true;
private static final boolean QUICK_BACK = true;
private static final boolean MAX_FREEFORM = true;
private static final boolean GESTURE_FIX = true;
private static final float GESTURE_AREA_MAX_DP = 32f;
private static final boolean GESTURE_ARROW_SCALE = true;
private ClassLoader cl;
private final ArrayList<WeakReference<View>> stubs = new ArrayList<>();
private boolean cbRegistered;
private interface Fn { void run(XC_MethodHook.MethodHookParam p) throws Throwable; }
private static XC_MethodHook before(final Fn f) {
return new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("HighEndHome: " + t); }
}
};
}
private static XC_MethodHook after(final Fn f) {
return new XC_MethodHook() {
@Override protected void afterHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("HighEndHome: " + t); }
}
};
}
private Class<?> c(String n) { return XposedHelpers.findClassIfExists(n, cl); }
private void hk(String cn, String m, XC_MethodHook h) {
Class<?> k = c(cn);
if (k == null) { XposedBridge.log("HighEndHome: missing class " + cn); return; }
try {
if (XposedBridge.hookAllMethods(k, m, h).isEmpty())
XposedBridge.log("HighEndHome: no method " + cn + "." + m);
} catch (Throwable t) { XposedBridge.log("HighEndHome: " + cn + "." + m + " " + t); }
}
private void ctor(String cn, XC_MethodHook h) {
Class<?> k = c(cn);
if (k == null) return;
try { XposedBridge.hookAllConstructors(k, h); } catch (Throwable ignored) {}
}
private static int dp(float v) {
DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
return (int) (v * dm.density + 0.5f);
}
private static Object cast(Method m, Number n) {
Class<?> r = m.getReturnType();
if (r == int.class) return n.intValue();
if (r == float.class) return n.floatValue();
if (r == long.class) return n.longValue();
if (r == double.class) return n.doubleValue();
return n;
}
private void run(String name, Runnable r) {
try { r.run(); } catch (Throwable t) { XposedBridge.log("HighEndHome " + name + ": " + t); }
}
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"com.miui.home".equals(lp.packageName)) return;
cl = lp.classLoader;
if (HIGH_END) run("highend", this::highEnd);
if (MIUI_WIDGETS) run("miuiWidgets", this::alwaysShowMiuiWidget);
if (WIDGET_TO_MINUS) run("widgetToMinus", this::widgetToMinus);
if (WIDGET_RESIZABLE) run("widgetResizable", this::widgetResizable);
if (WIDGET_HIDE_TITLE) run("widgetTitle", this::widgetHideTitle);
if (WIDGET_ALL_ANIM) run("widgetAnim", this::widgetAnim);
run("titleSize", this::titleFontSize);
if (HIDE_REPORT_TEXT) run("reportText", this::hideReportText);
if (NEW_INSTALL_INDICATOR_OFF) run("newInstall", () -> hk("com.miui.home.launcher.TitleTextView", "updateNewInstallIndicator", XC_MethodReplacement.returnConstant(null)));
if (DOWNLOAD_ANIMATION) run("download", this::downloadAnimation);
if (DISABLE_RECENTS_ICON) run("recentsIcon", () -> hk("com.miui.home.launcher.hotseats.HotSeatsListRecentsAppProvider", "updateFinalRecommendTasks", XC_MethodReplacement.returnConstant(true)));
if (UNLOCK_HOTSEAT) run("hotseat", () -> hk("com.miui.home.launcher.DeviceConfig", "getHotseatMaxCount", XC_MethodReplacement.returnConstant(99)));
if (HOTSEAT_LAYOUT) run("hotseatLayout", this::hotseatLayout);
if (RECENT_HIDE_CLEAN_UP) run("cleanUp", this::hideCleanUp);
if (RECENT_REMOVE_ICON) run("recentIcon", this::removeRecentIcon);
run("blurLevel", this::blurLevel);
run("taskView", this::taskViews);
run("animRatio", this::animRatio);
if (DRAWER_ALL) run("drawer", this::drawerAll);
if (FOLDER_RECOMMEND_OFF) run("folderRecommend", this::folderRecommend);
run("folder", this::folderTweaks);
if (TOAST_SLIDE_AGAIN) run("toast", this::toastSlideAgain);
if (OPT_LAUNCH_DELAY) run("launchDelay", this::optLaunchDelay);
if (SEEK_POINTS_HIDE) run("seek", this::seekPoints);
if (SHORTCUT_COUNT) run("shortcutCount", this::shortcutCount);
if (QUICK_BACK) run("quickBack", this::quickBack);
if (MAX_FREEFORM) run("maxFreeform", this::maxFreeForm);
if (GESTURE_FIX) run("gestureFix", this::gestureFix);
}
private void highEnd() {
for (String f : MIUI_BUILD_FALSE) setBuild(cl, f, false);
for (String f : MIUI_BUILD_TRUE) setBuild(cl, f, true);
for (String cn : BOOL_CLASSES) hookBooleans(cl, cn);
for (String cn : CPU_CLASSES) hookLevels(cl, cn);
hookDeviceLevel(cl);
XC_MethodHook two = XC_MethodReplacement.returnConstant(2);
hk("com.miui.home.launcher.common.CpuLevelUtils", "getQualcommCpuLevel", two);
hk("miuix.animation.utils.DeviceUtils", "getQualcommCpuLevel", two);
hk("miuix.device.DeviceUtils", "getQualcommCpuLevel", two);
hk("com.miui.home.launcher.DeviceConfig", "isUseSimpleAnim", XC_MethodReplacement.returnConstant(false));
hk("com.miui.home.launcher.DeviceConfig", "isSupportCompleteAnimation", XC_MethodReplacement.returnConstant(true));
hk("com.miui.home.launcher.DeviceConfig", "isMiuiLiteVersion", XC_MethodReplacement.returnConstant(false));
hk("com.miui.home.launcher.common.DeviceLevelUtils", "getDeviceLevel", two);
hk("com.miui.home.launcher.common.DeviceLevelUtils", "isLowLevelOrLiteDevice", XC_MethodReplacement.returnConstant(false));
hk("com.miui.home.launcher.util.noword.NoWordSettingHelperKt", "isNoWordAvailable", XC_MethodReplacement.returnConstant(true));
hk("com.miui.home.launcher.common.Utilities", "canLockTaskView", XC_MethodReplacement.returnConstant(true));
hk("com.miui.home.launcher.MIUIWidgetUtil", "isMIUIWidgetSupport", XC_MethodReplacement.returnConstant(true));
hk("com.xiaomi.onetrack.OneTrack", "isDisable", XC_MethodReplacement.returnConstant(true));
Class<?> sysProps = XposedHelpers.findClass("android.os.SystemProperties", null);
XposedBridge.hookAllMethods(sysProps, "getBoolean", before(p -> {
if (p.args.length >= 2 && p.args[0] instanceof String) {
String k = (String) p.args[0];
if (k.equals("ro.config.low_ram.threshold_gb")) p.setResult(false);
else if (k.equals("ro.miui.backdrop_sampling_enabled")) p.setResult(true);
}
}));
}
private void alwaysShowMiuiWidget() {
XC_MethodHook h = new XC_MethodHook() {
private final ThreadLocal<Set<XC_MethodHook.Unhook>> un = new ThreadLocal<>();
@Override protected void beforeHookedMethod(MethodHookParam p) {
Set<XC_MethodHook.Unhook> s = new HashSet<>();
try {
Class<?> a = c("com.miui.home.launcher.widget.MIUIAppWidgetInfo");
if (a != null) s.addAll(XposedBridge.hookAllMethods(a, "initMiuiAttribute", after(q -> XposedHelpers.setObjectField(q.thisObject, "isMIUIWidget", false))));
Class<?> u = c("com.miui.home.launcher.MIUIWidgetUtil");
if (u != null) s.addAll(XposedBridge.hookAllMethods(u, "isMIUIWidgetSupport", after(q -> q.setResult(false))));
} catch (Throwable t) { XposedBridge.log("HighEndHome miuiWidget: " + t); }
un.set(s);
}
@Override protected void afterHookedMethod(MethodHookParam p) {
Set<XC_MethodHook.Unhook> s = un.get();
if (s != null) for (XC_MethodHook.Unhook x : s) x.unhook();
un.remove();
}
};
if (c("com.miui.home.launcher.widget.WidgetsVerticalAdapter") != null)
hk("com.miui.home.launcher.widget.WidgetsVerticalAdapter", "buildAppWidgetsItems", h);
else
hk("com.miui.home.launcher.widget.BaseWidgetsVerticalAdapter", "buildAppWidgetsItems", h);
}
private void widgetToMinus() {
XC_MethodHook h = before(p -> {
Object stub = p.thisObject;
Object launcher;
Object dragCtl;
Object dragInfo;
if (p.args.length == 2) {
launcher = p.args[0];
dragInfo = XposedHelpers.callMethod(p.args[1], "getDragInfo");
dragCtl = XposedHelpers.callMethod(launcher, "getDragController");
} else {
dragCtl = XposedHelpers.getObjectField(stub, "mDragController");
Object cur = XposedHelpers.callMethod(dragCtl, "getCurrentDragObject");
dragInfo = cur == null ? null : XposedHelpers.callMethod(cur, "getDragInfo");
launcher = XposedHelpers.getObjectField(stub, "mLauncher");
}
Object cb = XposedHelpers.callMethod(launcher, "getLauncherCallbacks");
boolean from = (Boolean) XposedHelpers.callMethod(dragCtl, "isDraggingFromAssistant");
boolean to = (Boolean) XposedHelpers.callMethod(dragCtl, "isDraggingToAssistant");
Object spanX = dragInfo == null ? null : XposedHelpers.getObjectField(dragInfo, "spanX");
boolean one = spanX != null && ((Number) spanX).intValue() == 1;
p.setResult(cb != null && !from && !to && !one);
});
if (c("com.miui.home.launcher.widget.MIUIWidgetHelper") != null)
hk("com.miui.home.launcher.widget.MIUIWidgetHelper", "canDragToPa", h);
else
hk("com.miui.home.launcher.Workspace", "canDragToPa", h);
}
private void widgetResizable() {
XposedBridge.hookAllMethods(android.appwidget.AppWidgetHostView.class, "getAppWidgetInfo", after(p -> {
if (!(p.getResult() instanceof AppWidgetProviderInfo)) return;
AppWidgetProviderInfo i = (AppWidgetProviderInfo) p.getResult();
i.resizeMode = AppWidgetProviderInfo.RESIZE_VERTICAL | AppWidgetProviderInfo.RESIZE_HORIZONTAL;
i.minHeight = 0;
i.minWidth = 0;
i.minResizeHeight = 0;
i.minResizeWidth = 0;
}));
}
private void widgetHideTitle() {
hk("com.miui.home.launcher.LauncherAppWidgetHost", "createLauncherWidgetView", after(p -> {
if (p.args.length != 4 || p.getResult() == null) return;
Object t = XposedHelpers.callMethod(p.getResult(), "getTitleView");
if (t instanceof View) ((View) t).setVisibility(View.GONE);
}));
hk("com.miui.home.launcher.Launcher", "addMaMl", after(p -> {
if (p.getResult() == null) return;
Object t = XposedHelpers.callMethod(p.getResult(), "getTitleView");
if (t instanceof View) ((View) t).setVisibility(View.GONE);
}));
}
private void widgetAnim() {
hk("com.miui.home.launcher.LauncherWidgetView", "isUseTransitionAnimation", XC_MethodReplacement.returnConstant(true));
hk("com.miui.home.launcher.maml.MaMlWidgetView", "isUseTransitionAnimation", XC_MethodReplacement.returnConstant(true));
}
private void titleFontSize() {
final float desktop = TITLE_SIZE_DESKTOP;
final float drawer = TITLE_SIZE_DRAWER;
if (desktop == 12f && drawer == 12f) return;
final Class<?> appIcon = c("com.miui.home.launcher.AppIcon");
final float[] defPx = {-1f};
hk("com.miui.home.launcher.ShortcutIcon", "onMeasure", new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try {
if (defPx[0] < 0) {
Object v = XposedHelpers.callStaticMethod(c("com.miui.home.launcher.DeviceConfig"), "getIconTitleTextSize");
defPx[0] = ((Number) v).floatValue();
}
((TextView) p.thisObject).setTextSize(0, defPx[0]);
} catch (Throwable ignored) {}
}
@Override protected void afterHookedMethod(MethodHookParam p) {
try {
TextView t = (TextView) p.thisObject;
t.setTextSize(appIcon != null && appIcon.isInstance(t) ? drawer : desktop);
} catch (Throwable ignored) {}
}
});
if (desktop == 12f) return;
hk("com.miui.home.launcher.TitleTextView", "updateSizeOnIconSizeChanged",
before(p -> { ((TextView) p.thisObject).setTextSize(desktop); p.setResult(null); }));
ctor("com.miui.home.launcher.TitleTextView", after(p -> ((TextView) p.thisObject).setTextSize(desktop)));
}
private boolean reportHooked;
private void hideReportText() {
hk("com.miui.home.launcher.uninstall.BaseUninstallDialog", "init", before(p -> {
if (reportHooked) return;
reportHooked = true;
hk("com.miui.home.launcher.ShortcutInfo", "getInstallerPackageName", XC_MethodReplacement.returnConstant("com.xiaomi.market"));
}));
}
private void downloadAnimation() {
Class<?> d = c("com.miui.home.launcher.common.DeviceLevelUtils");
if (d != null) {
hk("com.miui.home.launcher.common.DeviceLevelUtils", "needMamlProgressIcon", XC_MethodReplacement.returnConstant(true));
hk("com.miui.home.launcher.common.DeviceLevelUtils", "needRemoveDownloadAnimationDevice", XC_MethodReplacement.returnConstant(false));
} else {
hk("com.miui.home.launcher.common.CpuLevelUtils", "needMamlDownload", XC_MethodReplacement.returnConstant(true));
}
}
private void hotseatLayout() {
hk("com.miui.home.launcher.DeviceConfig", "getHotSeatsHeight", XC_MethodReplacement.returnConstant(dp(HOTSEAT_HEIGHT_DP)));
hk("com.miui.home.launcher.DeviceConfig", "getHotSeatsMarginBottom", XC_MethodReplacement.returnConstant(dp(HOTSEAT_MARGIN_BOTTOM_DP)));
hk("com.miui.home.launcher.DeviceConfig", "calcHotSeatsMarginTop", before(p -> p.setResult(dp(HOTSEAT_MARGIN_TOP_DP))));
}
private static void hideClear(View root) {
if (root instanceof android.view.ViewGroup) {
android.view.ViewGroup g = (android.view.ViewGroup) root;
for (int i = 0; i < g.getChildCount(); i++) hideClear(g.getChildAt(i));
}
int id = root.getId();
if (id == View.NO_ID) return;
try {
String n = root.getResources().getResourceEntryName(id).toLowerCase();
if (n.contains("clear")) {
XposedHelpers.setAdditionalInstanceField(root, "jhide", Boolean.TRUE);
root.setVisibility(View.GONE);
}
} catch (Throwable ignored) {}
}
private void hideCleanUp() {
XposedBridge.hookAllMethods(View.class, "setVisibility", before(p -> {
if (p.args.length == 1 && XposedHelpers.getAdditionalInstanceField(p.thisObject, "jhide") != null) p.args[0] = View.GONE;
}));
XC_MethodHook h = after(p -> {
try {
Object v = XposedHelpers.getObjectField(p.thisObject, "mClearAnimView");
if (v instanceof View) { XposedHelpers.setAdditionalInstanceField(v, "jhide", Boolean.TRUE); ((View) v).setVisibility(View.GONE); }
} catch (Throwable ignored) {}
hideClear((View) p.thisObject);
});
hk("com.miui.home.recents.views.RecentsContainer", "onFinishInflate", h);
hk("com.miui.home.recents.views.RecentsContainer", "onAttachedToWindow", h);
}
private void removeRecentIcon() {
hk("com.miui.home.recents.views.TaskViewHeader", "onFinishInflate", after(p -> {
Object v = XposedHelpers.getObjectField(p.thisObject, "mIconView");
if (v instanceof View) ((View) v).setVisibility(View.GONE);
}));
}
private void blurLevel() {
if (RECENT_BLUR_LEVEL != 4) return;
hk("com.miui.home.launcher.common.BlurUtils", "getBlurType", XC_MethodReplacement.returnConstant(0));
hk("com.miui.home.launcher.common.BlurUtils", "isUseCompleteBlurOnDev", XC_MethodReplacement.returnConstant(false));
}
private void taskViews() {
if (TASK_HORIZONTAL_1 != 1f || TASK_HORIZONTAL_2 != 1f) {
hk("com.miui.home.recents.views.TaskStackViewsAlgorithmHorizontal", "scaleTaskView", after(p -> {
boolean land = (Boolean) XposedHelpers.callMethod(p.thisObject, "isLandscapeVisually");
XposedHelpers.callStaticMethod(c("com.miui.home.recents.util.Utilities"), "scaleRectAboutCenter",
p.args[0], land ? TASK_HORIZONTAL_2 : TASK_HORIZONTAL_1);
}));
}
if (TASK_VERTICAL != 1f) {
hk("com.miui.home.recents.views.TaskStackViewsAlgorithmVertical", "scaleTaskView", before(p -> {
Class<?> u = c("com.miui.home.recents.util.Utilities");
Object s = XposedHelpers.callStaticMethod(u, "getTaskViewScale", XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication"));
XposedHelpers.callStaticMethod(u, "scaleRectAboutCenter", p.args[0], TASK_VERTICAL * ((Number) s).floatValue());
p.setResult(null);
}));
}
if (TASK_CORNER_DP != 20) {
Class<?> w = c("com.miui.home.recents.util.WindowCornerRadiusUtil");
if (w != null) {
for (Method m : w.getDeclaredMethods()) {
if (!m.getName().equals("getTaskViewCornerRadius")) continue;
final Method mm = m;
XposedBridge.hookMethod(m, before(p -> p.setResult(cast(mm, TASK_CORNER_DP))));
}
}
final Map<Integer, Boolean> cache = new ConcurrentHashMap<>();
XC_MethodHook rh = before(p -> {
if (!(p.args[0] instanceof Integer)) return;
int id = (Integer) p.args[0];
Boolean hit = cache.get(id);
if (hit == null) {
hit = false;
try {
Resources r = (Resources) p.thisObject;
if ("dimen".equals(r.getResourceTypeName(id))) {
String n = r.getResourceEntryName(id);
hit = n.equals("recents_task_view_rounded_corners_radius_min")
|| n.equals("recents_task_view_rounded_corners_radius_max");
}
} catch (Throwable ignored) {}
cache.put(id, hit);
}
if (hit) {
Method m = (Method) p.method;
if (m.getReturnType() == float.class) p.setResult((float) dp(TASK_CORNER_DP));
else p.setResult(dp(TASK_CORNER_DP));
}
});
XposedBridge.hookAllMethods(Resources.class, "getDimension", rh);
XposedBridge.hookAllMethods(Resources.class, "getDimensionPixelOffset", rh);
XposedBridge.hookAllMethods(Resources.class, "getDimensionPixelSize", rh);
}
}
private void animRatio() {
if (ANIM_TITLE != 1f) {
hk("com.miui.home.recents.util.RectFSpringAnim", "getModifyResponse",
before(p -> p.setResult(((Number) p.args[0]).floatValue() * ANIM_TITLE)));
}
if (ANIM_RECENT != 1f) {
hk("com.miui.home.launcher.common.DeviceLevelUtils", "getDeviceLevelTransitionAnimRatio",
XC_MethodReplacement.returnConstant(ANIM_RECENT));
}
}
private void drawerAll() {
XC_MethodHook h = after(p -> {
Object r = p.getResult();
if (r instanceof ArrayList && ((ArrayList<?>) r).size() > 1) ((ArrayList<?>) r).remove(0);
});
if (c("com.miui.home.launcher.allapps.category.BaseAllAppsCategoryListContainer") != null)
hk("com.miui.home.launcher.allapps.category.BaseAllAppsCategoryListContainer", "buildSortCategoryList", h);
else
hk("com.miui.home.launcher.allapps.category.AllAppsCategoryListContainer", "buildSortCategoryList", h);
}
private void folderRecommend() {
hk("com.miui.home.launcher.Folder", "showRecommendAppsSwitch", after(p -> {
Object v = XposedHelpers.getObjectField(p.thisObject, "mRecommendAppsSwitch");
if (v instanceof View) ((View) v).setVisibility(View.GONE);
}));
}
private void folderTweaks() {
if (FOLDER_VERTICAL_SPACING_DP > 0) {
hk("com.miui.home.launcher.Folder", "bind", after(p -> {
Object g = XposedHelpers.getObjectField(p.thisObject, "mContent");
if (g instanceof GridView) ((GridView) g).setVerticalSpacing(dp(FOLDER_VERTICAL_SPACING_DP));
}));
}
if (FOLDER_TITLE_CENTER) {
hk("com.miui.home.launcher.Folder", "onOpen", after(p -> {
Object o = XposedHelpers.getObjectField(p.thisObject, "mTitleText");
if (!(o instanceof TextView)) return;
TextView t = (TextView) o;
if (t.getEllipsize() == TextUtils.TruncateAt.MARQUEE) return;
t.setEllipsize(TextUtils.TruncateAt.MARQUEE);
t.setHorizontalFadingEdgeEnabled(true);
t.setSingleLine();
t.setMarqueeRepeatLimit(-1);
t.setSelected(true);
t.setHorizontallyScrolling(true);
}));
hk("com.miui.home.launcher.Folder", "bind", after(p -> {
Object t = XposedHelpers.getObjectField(p.thisObject, "mTitleText");
Object e = XposedHelpers.getObjectField(p.thisObject, "mRenameEdit");
if (t instanceof TextView) {
TextView tv = (TextView) t;
tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
tv.setPadding(tv.getPaddingRight(), tv.getPaddingTop(), tv.getPaddingRight(), tv.getPaddingBottom());
}
if (e instanceof TextView) {
TextView ev = (TextView) e;
ev.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
ev.setPadding(ev.getPaddingRight(), ev.getPaddingTop(), ev.getPaddingRight(), ev.getPaddingBottom());
}
}));
}
}
private void toastSlideAgain() {
final Object[] holder = new Object[1];
XC_MethodHook h = new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try {
holder[0] = XposedHelpers.findAndHookMethod(Toast.class, "show", new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam q) { q.setResult(null); }
});
} catch (Throwable ignored) {}
}
@Override protected void afterHookedMethod(MethodHookParam p) {
if (holder[0] != null) { ((XC_MethodHook.Unhook) holder[0]).unhook(); holder[0] = null; }
}
};
hk("com.miui.home.recents.NavStubView", "onPointerEvent", h);
hk("com.miui.home.recents.GestureModeApp", "onStartGesture", h);
}
private void optLaunchDelay() {
hk("com.android.systemui.shared.recents.utilities.WindowTransitionCallbackHelper", "executeFinishCallback", before(p -> {
if (p.args.length > 5 && p.args[5] instanceof Boolean) p.args[5] = false;
}));
}
private void shortcutCount() {
String k = "com.miui.home.launcher.shortcuts.AppShortcutMenu";
hk(k, "getMaxCountInCurrentOrientation", after(p -> p.setResult(20)));
hk(k, "getMaxShortcutItemCount", after(p -> p.setResult(20)));
hk(k, "getMaxVisualHeight", after(p -> p.setResult(XposedHelpers.callMethod(p.thisObject, "getItemHeight"))));
}
private void seekPoints() {
String k = "com.miui.home.launcher.ScreenView";
hk(k, "setSeekBarPosition", after(p -> showSeekBar((View) p.thisObject)));
hk(k, "refreshScrollBound", after(p -> showSeekBar((View) p.thisObject)));
hk(k, "updateSeekPoints", before(p -> showSeekBar((View) p.thisObject)));
hk(k, "addView", before(p -> showSeekBar((View) p.thisObject)));
hk(k, "removeScreen", before(p -> showSeekBar((View) p.thisObject)));
hk(k, "removeScreensInLayout", before(p -> showSeekBar((View) p.thisObject)));
}
private void showSeekBar(View workspace) {
if (!"Workspace".equals(workspace.getClass().getSimpleName())) return;
boolean editing = (Boolean) XposedHelpers.callMethod(workspace, "isInNormalEditingMode");
Object bar = XposedHelpers.getObjectField(workspace, "mScreenSeekBar");
if (!(bar instanceof View)) return;
final View seek = (View) bar;
seek.animate().cancel();
if (!editing) {
seek.setAlpha(0f);
seek.setVisibility(View.GONE);
return;
}
seek.setVisibility(View.VISIBLE);
seek.animate().alpha(1f).setDuration(300);
}
private int[] qbValues;
private void maxFreeForm() {
String u = "com.miui.home.launcher.RecentsAndFSGestureUtils";
hk(u, "canTaskEnterSmallWindow", XC_MethodReplacement.returnConstant(true));
hk(u, "canTaskEnterMiniSmallWindow", before(p -> {
Object h = XposedHelpers.callStaticMethod(c("com.miui.home.smallwindow.SmallWindowStateHelper"), "getInstance");
p.setResult(XposedHelpers.callMethod(h, "canEnterMiniSmallWindow"));
}));
hk("com.miui.home.smallwindow.SmallWindowStateHelperUseManager", "canEnterMiniSmallWindow", before(p -> {
Object set = XposedHelpers.getObjectField(p.thisObject, "mMiniSmallWindowInfoSet");
p.setResult(((android.util.ArraySet<?>) set).isEmpty());
}));
hk("miui.app.MiuiFreeFormManager", "getAllFreeFormStackInfosOnDisplay", before(p -> { if (inStartSmall()) p.setResult(null); }));
hk("android.util.MiuiMultiWindowUtils", "hasSmallFreeform", before(p -> { if (inStartSmall()) p.setResult(false); }));
}
private static boolean inStartSmall() {
for (StackTraceElement e : new Throwable().getStackTrace())
if ("android.util.MiuiMultiWindowUtils".equals(e.getClassName()) && "startSmallFreeform".equals(e.getMethodName())) return true;
return false;
}
private static int physDensity() {
for (String f : new String[]{"DENSITY_DEVICE_STABLE", "DENSITY_DEVICE"}) {
try { int v = XposedHelpers.getStaticIntField(android.util.DisplayMetrics.class, f); if (v > 0) return v; } catch (Throwable ignored) {}
}
try { return (Integer) XposedHelpers.callStaticMethod(XposedHelpers.findClass("android.os.SystemProperties", null), "getInt", "ro.sf.lcd_density", 0); } catch (Throwable t) { return 0; }
}
private static boolean resized(View v, int phys) {
return phys > 0 && v.getResources().getDisplayMetrics().densityDpi != phys;
}
private static int gestureCap(View v) {
return Math.round(GESTURE_AREA_MAX_DP * v.getResources().getDisplayMetrics().densityDpi / 160f);
}
private static void refreshScreen(Object stub, View v) {
try {
android.view.WindowManager wm = (android.view.WindowManager) v.getContext().getSystemService("window");
android.graphics.Rect b = wm.getMaximumWindowMetrics().getBounds();
XposedHelpers.setIntField(stub, "mScreenWidth", b.width());
XposedHelpers.setIntField(stub, "mScreenHeight", b.height());
XposedHelpers.callMethod(stub, "updateGestureTouchHeight");
} catch (Throwable t) { XposedBridge.log("HighEndHome refreshScreen: " + t); }
}
private void gestureFix() {
final int phys = physDensity();
final String stub = "com.miui.home.recents.GestureStubView";
hk(stub, "initScreenSizeAndDensity", after(p -> {
View v = (View) p.thisObject;
if (!resized(v, phys)) return;
refreshScreen(p.thisObject, v);
int cap = gestureCap(v);
for (String f : new String[]{"mGestureStubDefaultSize", "mGestureStubSize"}) {
int cur = XposedHelpers.getIntField(p.thisObject, f);
if (cur > cap) XposedHelpers.setIntField(p.thisObject, f, cap);
}
}));
hk(stub, "setSize", before(p -> {
if (p.args.length != 1 || !(p.args[0] instanceof Integer)) return;
View v = (View) p.thisObject;
if (!resized(v, phys)) return;
int cap = gestureCap(v);
if ((Integer) p.args[0] > cap) p.args[0] = cap;
}));
ctor(stub, after(p -> {
View v = (View) p.thisObject;
synchronized (stubs) { stubs.add(new WeakReference<>(v)); }
if (cbRegistered) return;
cbRegistered = true;
v.getContext().getApplicationContext().registerComponentCallbacks(new ComponentCallbacks() {
@Override public void onConfigurationChanged(Configuration c) { reinitStubs(); }
@Override public void onLowMemory() {}
});
}));
if (GESTURE_ARROW_SCALE) hk("com.miui.home.recents.GestureBackArrowView", "onAttachedToWindow", after(p -> {
final View v = (View) p.thisObject;
final android.util.DisplayMetrics dm = v.getResources().getDisplayMetrics();
if (phys <= 0 || dm.densityDpi >= phys) return;
final float f = (float) dm.densityDpi / phys;
v.post(() -> {
int w = v.getWidth();
boolean left = v.getX() + w / 2f < dm.widthPixels / 2f;
v.setPivotX(left ? 0 : w);
v.setPivotY(v.getHeight() / 2f);
v.setScaleX(f);
v.setScaleY(f);
});
}));
}
private void reinitStubs() {
synchronized (stubs) {
for (int i = stubs.size() - 1; i >= 0; i--) {
final View v = stubs.get(i).get();
if (v == null) { stubs.remove(i); continue; }
v.post(() -> {
try {
XposedHelpers.callMethod(v, "initScreenSizeAndDensity", XposedHelpers.getIntField(v, "mRotation"));
XposedHelpers.callMethod(v, "updateGestureTouchHeight");
XposedHelpers.callMethod(v, "setSize", XposedHelpers.getIntField(v, "mGestureStubSize"));
} catch (Throwable t) { XposedBridge.log("HighEndHome reinit: " + t); }
});
}
}
}
private void quickBack() {
try {
Class<?> rs = c("com.miui.home.recents.GestureBackArrowView$ReadyState");
Object back = XposedHelpers.getStaticObjectField(rs, "READY_STATE_BACK");
Object recent = XposedHelpers.getStaticObjectField(rs, "READY_STATE_RECENT");
Object none = XposedHelpers.getStaticObjectField(rs, "READY_STATE_NONE");
Object[] vs = (Object[]) XposedHelpers.callStaticMethod(rs, "values");
qbValues = new int[vs.length];
qbValues[((Enum<?>) back).ordinal()] = 1;
qbValues[((Enum<?>) recent).ordinal()] = 2;
qbValues[((Enum<?>) none).ordinal()] = 3;
} catch (Throwable t) { qbValues = null; }
hk("com.miui.home.recents.GestureStubView", "isDisableQuickSwitch", XC_MethodReplacement.returnConstant(false));
hk("com.miui.home.recents.GestureStubView$3", "onSwipeStop", before(p -> {
if (p.args.length < 1 || !(p.args[0] instanceof Boolean) || !((Boolean) p.args[0])) return;
Object stub = XposedHelpers.getObjectField(p.thisObject, "this$0");
Object arrow = XposedHelpers.getObjectField(stub, "mGestureBackArrowView");
Object st = XposedHelpers.callMethod(arrow, "getCurrentState");
int ord = (Integer) XposedHelpers.callMethod(st, "ordinal");
if (qbValues == null) {
Class<?> x = c("com.miui.home.recents.GestureStubView$4");
if (x == null) x = c("com.miui.home.recents.GestureStubView$5");
int[] m = (int[]) XposedHelpers.getStaticObjectField(x, "$SwitchMap$com$miui$home$recents$GestureBackArrowView$ReadyState");
ord = m[ord];
} else ord = qbValues[ord];
if (ord == 2) XposedHelpers.callMethod(stub, "onBackCancelled");
}));
hk("com.miui.home.recents.GestureStubView", "getNextTask", before(p -> {
if (p.args.length != 3) return;
Context context = (Context) p.args[0];
Object recentsModel = XposedHelpers.callStaticMethod(c("com.miui.home.recents.RecentsModel"), "getInstance", context);
Object loader = XposedHelpers.callMethod(recentsModel, "getTaskLoader");
Object plan = XposedHelpers.callMethod(loader, "createLoadPlan", context);
XposedHelpers.callMethod(loader, "preloadTasks", plan, -1);
Object stack = XposedHelpers.callMethod(plan, "getTaskStack");
ActivityManager.RunningTaskInfo running = null;
if (stack != null && (Integer) XposedHelpers.callMethod(stack, "getTaskCount") != 0)
running = (ActivityManager.RunningTaskInfo) XposedHelpers.callMethod(recentsModel, "getRunningTask");
if (stack == null || running == null) { p.setResult(null); return; }
ArrayList<?> tasks = (ArrayList<?>) XposedHelpers.callMethod(stack, "getStackTasks");
Object task = null;
for (int i = 0; i < tasks.size() - 1; i++) {
Object t = tasks.get(i);
Object key = XposedHelpers.getObjectField(t, "key");
if (XposedHelpers.getIntField(key, "id") == running.id) { task = tasks.get(i + 1); break; }
}
if (task == null && !tasks.isEmpty() && "com.miui.home".equals(running.baseActivity.getPackageName()))
task = tasks.get(0);
if (task != null && XposedHelpers.getObjectField(task, "icon") == null) {
XposedHelpers.setObjectField(task, "icon", XposedHelpers.callMethod(loader, "getAndUpdateActivityIcon",
XposedHelpers.getObjectField(task, "key"), XposedHelpers.getObjectField(task, "taskDescription"),
context.getResources(), true));
}
if (!(Boolean) p.args[1] || task == null) { p.setResult(task); return; }
ActivityOptions opts = null;
int pos = (Integer) p.args[2];
if (pos == 0) opts = ActivityOptions.makeCustomAnimation(context, anim(context, "recents_quick_switch_left_enter"), anim(context, "recents_quick_switch_left_exit"));
else if (pos == 1) opts = ActivityOptions.makeCustomAnimation(context, anim(context, "recents_quick_switch_right_enter"), anim(context, "recents_quick_switch_right_exit"));
Object am = XposedHelpers.callStaticMethod(Class.forName("android.app.ActivityManagerNative"), "getDefault");
if (am != null) {
Object key = XposedHelpers.getObjectField(task, "key");
if (XposedHelpers.getIntField(key, "windowingMode") == 3) {
if (opts == null) opts = ActivityOptions.makeBasic();
XposedHelpers.callMethod(opts, "setLaunchWindowingMode", 4);
}
XposedHelpers.callMethod(am, "startActivityFromRecents", XposedHelpers.getIntField(key, "id"), opts == null ? null : opts.toBundle());
}
p.setResult(task);
}));
}
private final Map<String, Integer> animIds = new ConcurrentHashMap<>();
private int anim(Context ctx, String name) {
Integer v = animIds.get(name);
if (v == null) { v = ctx.getResources().getIdentifier(name, "anim", ctx.getPackageName()); animIds.put(name, v); }
return v;
}
private static final String[] BOOL_CLASSES = {
"com.miui.home.launcher.MIUIWidgetUtil",
"com.miui.home.launcher.widget.MIUIWidgetUtil",
"com.miui.home.launcher.common.DeviceLevelUtils",
"com.miui.home.launcher.DeviceConfig",
"com.miui.home.launcher.common.Utilities",
"com.miui.home.launcher.Application",
"com.miui.home.recents.util.Utilities",
"com.miui.home.launcher.util.DeviceLevelUtils",
"com.miui.home.launcher.common.CpuLevelUtils",
"com.miui.home.launcher.common.BlurUtils",
"com.miui.home.launcher.graphics.BlurUtils"
};
private static final String[] CPU_CLASSES = {
"com.miui.home.launcher.common.CpuLevelUtils",
"com.miui.home.launcher.common.DeviceLevelUtils"
};
private static final String[] MIUI_BUILD_FALSE = {
"IS_MIUI_LITE_VERSION", "IS_MIDDLE_DEVICE", "IS_LOW_MEMORY_DEVICE",
"IS_LOW_END_DEVICE", "IS_MI_LITE_VERSION"
};
private static final String[] MIUI_BUILD_TRUE = {
"IS_HIGH_END_DEVICE"
};
private void setBuild(ClassLoader cl, String field, boolean v) {
try {
Class<?> c = XposedHelpers.findClass("miui.os.Build", cl);
XposedHelpers.setStaticBooleanField(c, field, v);
} catch (Throwable ignored) {}
}
private void hookBooleans(ClassLoader cl, String cn) {
Class<?> c;
try { c = XposedHelpers.findClass(cn, cl); } catch (Throwable t) { return; }
for (Method m : c.getDeclaredMethods()) {
if (m.getReturnType() != boolean.class) continue;
if (m.getParameterTypes().length > 1) continue;
String n = m.getName().toLowerCase();
Boolean ret = null;
boolean lowish = n.contains("lowlevel") || n.contains("lowend") || n.contains("lowmem")
|| n.contains("lite") || n.contains("simpleanim") || n.contains("middledevice")
|| n.contains("middlelevel") || n.contains("lowperformance") || n.contains("islow");
boolean highish = n.contains("highend") || n.contains("highlevel") || n.contains("highperformance")
|| n.contains("highmodel") || n.contains("ishigh");
boolean feature = n.contains("supportblur") || n.contains("supportbackgroundblur")
|| n.contains("isblursupport") || n.contains("supportcompleteanim")
|| n.contains("supportmamlanim") || n.contains("supportadvancedanim")
|| n.contains("supportshadow") || n.contains("supportsmoothcorner")
|| n.contains("needmamlprogressbar") || n.contains("enableblur");
if (lowish) ret = Boolean.FALSE;
else if (highish || feature) ret = Boolean.TRUE;
if (ret == null) continue;
try {
XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(ret));
} catch (Throwable t) {
XposedBridge.log("HighEndHome: " + cn + "." + m.getName() + " " + t);
}
}
}
private void hookLevels(ClassLoader cl, String cn) {
Class<?> c;
try { c = XposedHelpers.findClass(cn, cl); } catch (Throwable t) { return; }
for (Method m : c.getDeclaredMethods()) {
if (m.getReturnType() != int.class) continue;
String n = m.getName().toLowerCase();
if (n.contains("cpulevel") || n.equals("getdevicelevel") || n.contains("devicelevelforanim")
|| n.contains("devicelevelforblur") || n.contains("devicelevelfortransition")) {
try {
XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(2));
} catch (Throwable t) {
XposedBridge.log("HighEndHome: " + cn + "." + m.getName() + " " + t);
}
}
}
}
private void hookDeviceLevel(ClassLoader cl) {
try {
Class<?> c = XposedHelpers.findClass("miui.util.DeviceLevel", cl);
for (Method m : c.getDeclaredMethods()) {
String n = m.getName().toLowerCase();
if (m.getReturnType() == int.class && n.startsWith("getdevicelevel")) {
XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(2));
} else if (m.getReturnType() == boolean.class && (n.contains("islow") || n.contains("lite"))) {
XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(false));
}
}
for (String f : new String[]{"DEVICE_LEVEL"}) {
try { XposedHelpers.setStaticIntField(c, f, 2); } catch (Throwable ignored) {}
}
} catch (Throwable ignored) {}
}
}
